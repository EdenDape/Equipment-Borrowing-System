/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package MainClass;

/**
 *
 * @author
 */
import controller.EquipmentController;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import model.EquipmentManager;
import utils.FileDBHelper;
import view.MainUI;

public class MainClass {

    public static void main(String[] args) {
        // 1. Initialize project directory
        FileDBHelper.createDirectory();

        // 2. Look and Feel
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
            Logger.getLogger(MainClass.class.getName()).log(Level.SEVERE, "Error setting System Look and Feel", ex);
        }

        // A. Create the Model and load data
        EquipmentManager equipmentManager = new EquipmentManager();
        equipmentManager.loadEquipments();

        // B. Create the Controller, injecting the Model
        EquipmentController controller = new EquipmentController(equipmentManager);

        // 3. Launch the View on the Event Dispatch Thread
        java.awt.EventQueue.invokeLater(() -> {
            MainUI view = new MainUI(controller);
            controller.setView(view);
            view.addWindowListener(new java.awt.event.WindowAdapter() {
                @Override
                public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                    equipmentManager.saveEquipments();
                    System.exit(0);
                }
            });
            view.setVisible(true);
        });
    }
}
