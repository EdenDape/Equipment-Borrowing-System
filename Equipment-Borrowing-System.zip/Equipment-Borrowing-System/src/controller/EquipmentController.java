/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

/**
 *
 * @author
 */

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import model.Equipment;
import model.EquipmentManager;
import view.MainUI;

/**
 * Controller for the Equipment (main entity). Same flow as ItemController.
 */
public class EquipmentController {
    // sort options used by the Sort menu
    public static final String SORT_NAME = "NAME";
    public static final String SORT_SERIAL = "SERIAL";
    public static final String SORT_TYPE = "TYPE";
    public static final String SORT_STATUS = "STATUS";
    public static final String SORT_DUE = "DUE";

    private final EquipmentManager model;
    private MainUI view;

    public EquipmentController(EquipmentManager model){
        this.model = model;
    }

    public void setView(MainUI view){
        this.view = view;
    }

    /**
     * Validation shared by add and update.
     *
     * @param excludeId the equipment being edited (null when adding), so its own serial no. is not counted as a duplicate
     * @return true - if something is missing or invalid
     */
    private boolean isInvalid(String name, String serial, int typeId,
                              String borrower, String borrowerType, LocalDate borrowed,
                              LocalDate due, String excludeId){
        if (name.trim().isEmpty() || serial.trim().isEmpty()) {
            return true;
        }
        if (typeId == -1) {
            return true;
        }
        if (this.model.serialExists(serial.trim(), excludeId)) {
            return true;
        }
        // a borrowed item (borrower name given) needs a borrower type, borrowed date and due date
        if (!borrower.trim().isEmpty()) {
            if (borrowerType == null || borrowerType.trim().isEmpty()) {
                return true;
            }
            if (borrowed == null || due == null) {
                return true;
            }
            // the due date cannot be before the day it was borrowed
            if (due.isBefore(borrowed)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Add new equipment using the details from the view.
     * Equipment with a borrower name is Borrowed, without a borrower name it is Available.
     *
     * @param name
     * @param serial
     * @param typeId
     * @param borrower blank if the equipment is available
     * @param borrowerType Student / Faculty / Staff / Guest (ignored if available)
     * @param borrowed null if the equipment is available
     * @param due null if the equipment is available
     * @return true - if adding the new Equipment object is successful
     * @return false - if the operation fails to add the new Equipment object
     */
    public boolean handleAddEquipment(String name, String serial, int typeId,
                                      String borrower, String borrowerType,
                                      LocalDate borrowed, LocalDate due){
        //1. validation: return if missing field is present
        if (isInvalid(name, serial, typeId, borrower, borrowerType, borrowed, due, null)) {
            return false;
        }
        //2. no borrower means the equipment is available
        boolean available = borrower.trim().isEmpty();
        if (available) {
            borrowerType = "";
            borrowed = null;
            due = null;
        }
        //3. create new equipment object
        Equipment equipment = new Equipment(name.trim(), serial.trim().toUpperCase(),
                typeId, available, borrower.trim(), borrowerType.trim(), borrowed, due);
        //4. Controller adds new equipment object
        this.model.addEquipment(equipment);
        //5. save the changes to file for persistence
        int res = this.model.saveEquipments();
        //6. return false if adding fails
        if (res == -1) {
            return false;
        }
        //7. Update the view to reflect changes
        if (this.view != null) {
            this.view.refreshEquipments();
        }
        return true;
    }

    /**
     * Delete the equipment given the String id
     *
     * @param id
     * @return true - if the delete is successfully carried out
     * @return false - if the operation fails to deletion
     */
    public boolean handleDeleteEquipment(String id){
        //1. Delete the data based on the given string id
        Equipment equipment = this.model.deleteEquipment(id);
        if (equipment != null) {
            this.model.saveEquipments(); //persist change
            //2. This is for logging
            System.out.println("Deleted Equipment: " + equipment);
            //3. Refresh/Update the view
            if (this.view != null) {
                this.view.refreshEquipments();
            }
            return true;
        } else {
            System.out.println("Equipment not found");
            return false;
        }
    }

    /**
     * Update the Equipment information using the info from the view
     *
     * @param id
     * @param name
     * @param serial
     * @param typeId
     * @param borrower blank if the equipment is available
     * @param borrowerType Student / Faculty / Staff / Guest (ignored if available)
     * @param borrowed null if the equipment is available
     * @param due null if the equipment is available
     * @return true - if the update is successfully carried out
     * @return false - if the operation fails to update
     */
    public boolean handleUpdateEquipment(String id, String name, String serial, int typeId,
                                         String borrower, String borrowerType,
                                         LocalDate borrowed, LocalDate due){
        //1. Check if some fields are empty
        if (isInvalid(name, serial, typeId, borrower, borrowerType, borrowed, due, id)) {
            return false;
        }
        //2. Find the equipment to be updated from the list
        Equipment equipment = this.model.findEquipment(id);
        //3. Return false if equipment is null
        if (equipment == null) {
            return false;
        }
        //4. Update equipment
        boolean available = borrower.trim().isEmpty();
        if (available) {
            borrowerType = "";
            borrowed = null;
            due = null;
        }
        equipment.setName(name.trim());
        equipment.setSerialNo(serial.trim().toUpperCase());
        equipment.setEquipmentTypeId(typeId);
        equipment.setAvailable(available);
        equipment.setBorrowerName(borrower.trim());
        equipment.setBorrowerType(borrowerType.trim());
        equipment.setBorrowedDate(borrowed);
        equipment.setDueDate(due);
        //5. Save changes to file
        int res = this.model.saveEquipments();
        if (res == -1) {
            return false;
        }
        //6. Update the view
        if (this.view != null) {
            this.view.refreshEquipments();
        }
        return true;
    }

    /**
     * The borrower returns the equipment, so it becomes available again
     *
     * @param id
     * @return true - if the equipment is successfully returned
     * @return false - if it is not found or is already available
     */
    public boolean handleReturnEquipment(String id){
        //1. Find the equipment
        Equipment equipment = this.model.findEquipment(id);
        //2. Return false if it is null or not borrowed
        if (equipment == null || equipment.isAvailable()) {
            return false;
        }
        //3. Clear the borrower, borrower type, borrowed date and due date
        equipment.returnEquipment();
        //4. Save changes to file
        int res = this.model.saveEquipments();
        if (res == -1) {
            return false;
        }
        //5. Update the view
        if (this.view != null) {
            this.view.refreshEquipments();
        }
        return true;
    }

    /**
     * Retrieves all the list of Equipment from the model, already sorted
     *
     * @param sortBy one of SORT_NAME, SORT_SERIAL, SORT_TYPE, SORT_STATUS, SORT_DUE
     * @return List<Equipment>
     */
    public List<Equipment> getAllEquipments(String sortBy){
        //1. Get the raw Hashmap from model
        Collection<Equipment> equipmentsFromHash = this.model.findAll().values();
        //2. Convert the collections to list
        ArrayList<Equipment> equipmentList = new ArrayList<>(equipmentsFromHash);
        //3. Sort the list using Insertion Sort (stable)
        Comparator<Equipment> byName = Comparator
                .comparing((Equipment e) -> e.getName().toLowerCase())
                .thenComparing(e -> e.getSerialNo().toLowerCase());

        switch (sortBy) {
            case SORT_SERIAL:
                insertionSort(equipmentList, Comparator.comparing((Equipment e) -> e.getSerialNo().toLowerCase()));
                break;
            case SORT_TYPE:
                insertionSort(equipmentList, Comparator.comparingInt(Equipment::getEquipmentTypeId).thenComparing(byName));
                break;
            case SORT_STATUS:
                // OVERDUE first, then Borrowed, then Available
                insertionSort(equipmentList, Comparator.comparingInt(EquipmentController::statusRank).thenComparing(byName));
                break;
            case SORT_DUE:
                // earliest due date first, equipment without a due date (available) last
                insertionSort(equipmentList, Comparator.comparing(Equipment::getDueDate,
                        Comparator.nullsLast(Comparator.<LocalDate>naturalOrder())).thenComparing(byName));
                break;
            case SORT_NAME:
            default:
                insertionSort(equipmentList, byName);
        }
        return equipmentList;
    }

    public List<Equipment> getAllEquipments(){
        return getAllEquipments(SORT_NAME);
    }

    
    private static void insertionSort(List<Equipment> list, Comparator<Equipment> comparator){
        for (int i = 1; i < list.size(); i++) {
            Equipment key = list.get(i);
            int j = i - 1;
            // shift bigger items to the right; only strictly greater, so equal items keep their order
            while (j >= 0 && comparator.compare(list.get(j), key) > 0) {
                list.set(j + 1, list.get(j));
                j--;
            }
            list.set(j + 1, key);
        }
    }

    private static int statusRank(Equipment e){
        if (e.isOverdue()) return 0;
        if (!e.isAvailable()) return 1;
        return 2;
    }

    /**
     * Retrieves a specific Equipment object from the model to display its details in
     * the View.
     *
     * @param id The unique id of an Equipment
     * @return The Equipment object if found, null otherwise
     */
    public Equipment getEquipmentDetails(String id){
        return model.findEquipment(id);
    }
}
