/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

/**
 *
 * @author
 */

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import model.EquipmentType;
import model.EquipmentTypeManager;
import view.EquipmentTypeUI;

/**
 * Controller for the EquipmentType (lookup) form. Same flow as CategoryController.
 */
public class EquipmentTypeController {
    private final EquipmentTypeManager model;
    private EquipmentTypeUI view;

    public EquipmentTypeController(EquipmentTypeManager model){
        this.model = model;
    }

    public void setView(EquipmentTypeUI view){
        this.view = view;
    }

    public boolean handleAddEquipmentType(int id, String name){
        //1. validation
        if (name.trim().isEmpty()) {
            return false;
        }
        //2. create new equipment type object
        EquipmentType equipmentType = new EquipmentType(id, name.trim());
        //3. Controller adds new equipment type object
        this.model.addEquipmentType(equipmentType);
        //4. save the changes to file for persistence
        int res = this.model.saveEquipmentTypes();
        //5. return false if saving fails
        if (res == -1) {
            return false;
        }
        //6. Update the view to reflect changes
        if (this.view != null) {
            this.view.refreshEquipmentTypes();
        }
        return true;
    }

    public boolean handleUpdateEquipmentType(int id, String name){
        //1. Check if some fields are empty
        if (name.trim().isEmpty()) {
            return false;
        }
        //2. Find the equipment type to be updated from the list
        EquipmentType equipmentType = this.model.findEquipmentType(id);
        //3. Return false if it is null
        if (equipmentType == null) {
            return false;
        }
        //4. Update equipment type
        equipmentType.setTypeName(name.trim());

        //5. Save changes to file
        int res = this.model.saveEquipmentTypes();
        if (res == -1) {
            return false;
        }
        //6. Update the view
        if (this.view != null) {
            this.view.refreshEquipmentTypes();
        }
        return true;
    }

    public List<EquipmentType> getAllEquipmentType(){
        //1. Get the raw Hashmap from model
        Collection<EquipmentType> typesFromHash = this.model.findAll().values();
        //2. Convert the collections to list
        ArrayList<EquipmentType> typeList = new ArrayList<>(typesFromHash);
        return typeList;
    }

    public EquipmentType getEquipmentTypeDetails(int id){
        return model.findEquipmentType(id);
    }

    /** Next free id for a new equipment type. */
    public int getNextId(){
        return model.nextId();
    }

}
