/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;
/**
 *
 * @author
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.table.AbstractTableModel;
import model.Equipment;
import model.EquipmentType;

public class EquipmentTableModel extends AbstractTableModel {
    private List<Equipment> equipments;
    private Map<Integer, EquipmentType> typeMap;

    private final String[] COLUMN_NAMES = {"Equipment ID", "Name", "Serial No.",
        "Type", "Status", "Borrower", "Borrower Type", "Borrowed Date", "Due Date"};

    public EquipmentTableModel(){
        this.equipments = new ArrayList<>();
        this.typeMap = new HashMap<>();
    }

    @Override
    public int getRowCount() {
        return this.equipments.size();
    }

    @Override
    public int getColumnCount() {
        return this.COLUMN_NAMES.length;
    }

    @Override
    public String getColumnName(int column) {
        return this.COLUMN_NAMES[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Equipment e = equipments.get(rowIndex);
        return switch (columnIndex) {
            case 0 -> e.getEquipmentId();
            case 1 -> e.getName();
            case 2 -> e.getSerialNo();
            case 3 -> {
                EquipmentType type = typeMap.get(e.getEquipmentTypeId());
                yield type != null ? type.getTypeName() : "Unknown";
            }
            case 4 -> e.getStatus();
            case 5 -> e.getBorrowerName().isEmpty() ? "-" : e.getBorrowerName();
            case 6 -> e.getBorrowerType().isEmpty() ? "-" : e.getBorrowerType();
            case 7 -> e.getBorrowedDate() == null ? "-" : e.getBorrowedDate().toString();
            case 8 -> e.getDueDate() == null ? "-" : e.getDueDate().toString();
            default -> null;
        };
    }

    public void setEquipments(List<Equipment> equipments){
        this.equipments = equipments;
        fireTableDataChanged();
    }

    public void setEquipmentTypes(List<EquipmentType> types){
        this.typeMap = new HashMap<>();

        for (EquipmentType type : types) {
            typeMap.put(type.getId(), type);
        }
        fireTableDataChanged();
    }

    public String getEquipmentId(int rowIndex){
        return equipments.get(rowIndex).getEquipmentId();
    }
}
