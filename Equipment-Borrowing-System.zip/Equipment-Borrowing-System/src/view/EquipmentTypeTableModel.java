/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;
/**
 *
 * @author
 */
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;
import model.EquipmentType;

public class EquipmentTypeTableModel extends AbstractTableModel {
    private List<EquipmentType> types;
    private final String[] COLUMN_NAMES = {"ID", "Equipment Type"};

    public EquipmentTypeTableModel(){
        this.types = new ArrayList<>();
    }

    @Override
    public int getRowCount() {
        return types.size();
    }

    @Override
    public int getColumnCount() {
        return COLUMN_NAMES.length;
    }

    @Override
    public String getColumnName(int column) {
        return this.COLUMN_NAMES[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        EquipmentType type = types.get(rowIndex);
        return switch (columnIndex) {
            case 0 -> type.getId();
            case 1 -> type.getTypeName();
            default -> null;
        };
    }

    public void setEquipmentTypes(List<EquipmentType> types){
        this.types = types;
        fireTableDataChanged();
    }

    public int getEquipmentTypeId(int rowIndex) {
        return types.get(rowIndex).getId();
    }
}
