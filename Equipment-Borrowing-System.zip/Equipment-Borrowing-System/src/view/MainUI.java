/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package view;

import controller.EquipmentController;
import controller.EquipmentTypeController;
import java.awt.Color;
import java.awt.Component;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import model.Equipment;
import model.EquipmentType;
import model.EquipmentTypeManager;

/**
 *
 * Main form of the Equipment Borrowing System (computer laboratory).
 */
public class MainUI extends javax.swing.JFrame {

    /**
     * Creates new form MainUI
     */
    public MainUI(EquipmentController controller) {
        this.controller = controller;
        this.tableModel = new EquipmentTableModel();

        initEquipmentType();
        initComponents();
        setupListTable();
        setupRowsActionListener();
        populateComboBox();
        setUpDefaults();

        setLocationRelativeTo(null);

        // when you come back from Manage > Equipment Type, the new types show up right away
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowActivated(java.awt.event.WindowEvent e) {
                populateComboBox();
            }
        });

        refreshEquipments();
    }

    // Set MVC components for EquipmentType (same as initCategory() of the instructor)
    private void initEquipmentType() {
        // 1. Create model and load data
        typeManager = new EquipmentTypeManager();
        typeManager.loadEquipmentTypes();
        // 2. Create the controller
        typeController = new EquipmentTypeController(typeManager);

        // first run: add some default types so the Equipment Type combo box is not empty
        if (typeController.getAllEquipmentType().isEmpty()) {
            typeController.handleAddEquipmentType(typeController.getNextId(), "Laptop");
            typeController.handleAddEquipmentType(typeController.getNextId(), "Projector");
            typeController.handleAddEquipmentType(typeController.getNextId(), "Monitor");
            typeController.handleAddEquipmentType(typeController.getNextId(), "Camera");
            typeController.handleAddEquipmentType(typeController.getNextId(), "Router");
        }
    }

    //default display
    private void setUpDefaults() {
        //default buttons
        this.jBtnAdd.setEnabled(true);
        this.jBtnUpdate.setEnabled(false);
        this.jBtnDelete.setEnabled(false);
        this.jBtnReturn.setEnabled(false);

        //default text fields
        this.jTFName.setText("");
        this.jTFSerialNo.setText("");
        this.jComboBoxType.setSelectedIndex(-1);
        this.jTFBorrowerName.setText("");
        this.jComboBoxBorrowerType.setSelectedIndex(-1);
        this.jTFBorrowedDate.setText("");
        this.jTFDueDate.setText("");

        this.selectedEquipmentId = null;
        this.jTableEquipments.clearSelection();
        this.jTFName.requestFocusInWindow();
    }

    //setup table model
    private void setupListTable() {
        //set the modified tablemodel
        jTableEquipments.setModel(tableModel);
        jTableEquipments.getTableHeader().setReorderingAllowed(false);
        jTableEquipments.setAutoCreateColumnsFromModel(true);
        jTableEquipments.createDefaultColumnsFromModel();
        setupTableColumnWidths();
    }

    private void setupTableColumnWidths() {
        javax.swing.table.TableColumnModel columnModel = jTableEquipments.getColumnModel();

        columnModel.getColumn(0).setPreferredWidth(140);  // Equipment ID
        columnModel.getColumn(0).setMaxWidth(160);
        columnModel.getColumn(1).setPreferredWidth(150);  // Name
        columnModel.getColumn(2).setPreferredWidth(110);  // Serial No.
        columnModel.getColumn(3).setPreferredWidth(100);  // Type
        columnModel.getColumn(4).setPreferredWidth(90);   // Status
        columnModel.getColumn(5).setPreferredWidth(130);  // Borrower
        columnModel.getColumn(6).setPreferredWidth(100);  // Borrower Type
        columnModel.getColumn(7).setPreferredWidth(100);  // Borrowed Date
        columnModel.getColumn(8).setPreferredWidth(100);  // Due Date

        // Status column: green = Available, red = OVERDUE
        columnModel.getColumn(4).setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int row, int col) {
                Component c = super.getTableCellRendererComponent(t, v, sel, foc, row, col);
                if (!sel) {
                    String s = String.valueOf(v);
                    c.setForeground(s.equals("OVERDUE") ? Color.RED
                            : s.equals("Available") ? new Color(0, 130, 0) : Color.BLACK);
                }
                return c;
            }
        });

        jTableEquipments.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_LAST_COLUMN);
    }

    private void setupRowsActionListener() {
        jTableEquipments.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int selectedRow = jTableEquipments.getSelectedRow();
                //if row is selected
                if (selectedRow != -1) {
                    int modelRow = jTableEquipments.convertRowIndexToModel(selectedRow);
                    String equipmentId = this.tableModel.getEquipmentId(modelRow);
                    Equipment selected = controller.getEquipmentDetails(equipmentId);
                    if (selected != null) {
                        displaySelectedEquipment(selected);
                    }
                }
            }
        });
    }

    private void displaySelectedEquipment(Equipment equipment) {
        this.jTFName.setText(equipment.getName());
        this.jTFSerialNo.setText(equipment.getSerialNo());
        this.jTFBorrowerName.setText(equipment.getBorrowerName());
        this.jComboBoxBorrowerType.setSelectedItem(equipment.getBorrowerType().isEmpty() ? null : equipment.getBorrowerType());
        this.jTFBorrowedDate.setText(equipment.getBorrowedDate() == null ? "" : equipment.getBorrowedDate().toString());
        this.jTFDueDate.setText(equipment.getDueDate() == null ? "" : equipment.getDueDate().toString());
        this.selectedEquipmentId = equipment.getEquipmentId();

        this.jComboBoxType.setSelectedIndex(-1);
        for (int i = 0; i < jComboBoxType.getItemCount(); i++) {
            if (jComboBoxType.getItemAt(i).getId() == equipment.getEquipmentTypeId()) {
                jComboBoxType.setSelectedIndex(i);
                break;
            }
        }

        // set display for buttons
        this.jBtnAdd.setEnabled(false);
        this.jBtnUpdate.setEnabled(true);
        this.jBtnDelete.setEnabled(true);
        this.jBtnReturn.setEnabled(!equipment.isAvailable());
    }

    private void populateComboBox() {
        // remember the selection so it is not lost when the list is reloaded
        EquipmentType selected = (EquipmentType) jComboBoxType.getSelectedItem();

        List<EquipmentType> typeList = typeController.getAllEquipmentType();
        jComboBoxType.setModel(new DefaultComboBoxModel<>(typeList.toArray(new EquipmentType[0])));
        jComboBoxType.setSelectedIndex(-1);

        if (selected != null) {
            for (int i = 0; i < jComboBoxType.getItemCount(); i++) {
                if (jComboBoxType.getItemAt(i).getId() == selected.getId()) {
                    jComboBoxType.setSelectedIndex(i);
                    break;
                }
            }
        }
    }

    //refresh equipments (always sorted by the option chosen in the Sort menu)
    public void refreshEquipments() {
        String savedSelectedId = this.selectedEquipmentId;

        List<Equipment> equipments = controller.getAllEquipments(this.currentSort);
        List<EquipmentType> types = typeController.getAllEquipmentType();

        for (Equipment equipment : equipments) {
            System.out.println(equipment);
        }
        //Update the JTableModel
        this.tableModel.setEquipments(equipments);
        this.tableModel.setEquipmentTypes(types);

        // show which sort is active
        this.jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null,
                "Equipment - sorted by " + this.currentSortLabel,
                javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION));

        if (savedSelectedId != null) {
            int newModelRow = -1;
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                if (savedSelectedId.equals(tableModel.getEquipmentId(i))) {
                    newModelRow = i;
                    break;
                }
            }
            if (newModelRow != -1) {
                int newTableRow = jTableEquipments.convertRowIndexToView(newModelRow);
                jTableEquipments.setRowSelectionInterval(newTableRow, newTableRow);
            } else {
                this.selectedEquipmentId = null;
                setUpDefaults();
            }
        }
    }

    // ---------- sorting ----------
    private void applySort(String sortKey, String label) {
        this.currentSort = sortKey;
        this.currentSortLabel = label;
        refreshEquipments();
    }

    // ---------- helpers for reading the form ----------
    private static class FormData {
        int typeId = -1;
        String borrower = "";
        String borrowerType = "";
        LocalDate borrowed;
        LocalDate due;
    }

    private void showError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Equipment Borrowing", JOptionPane.ERROR_MESSAGE);
    }

    /** Reads and checks the form. Returns null (after showing a message) if something is wrong. */
    private FormData readForm() {
        FormData f = new FormData();

        EquipmentType type = (EquipmentType) this.jComboBoxType.getSelectedItem();
        if (type == null) {
            showError("Select an equipment type (add more in Manage > Equipment Type)");
            return null;
        }
        f.typeId = type.getId();

        // borrower name filled = Borrowed (needs type, borrowed date, due date); blank = Available
        f.borrower = this.jTFBorrowerName.getText().trim();
        if (!f.borrower.isEmpty()) {
            String borrowerType = (String) this.jComboBoxBorrowerType.getSelectedItem();
            if (borrowerType == null) {
                showError("Select a borrower type (Student, Faculty, Staff or Guest)");
                return null;
            }
            f.borrowerType = borrowerType;

            // a blank borrowed date means it is being borrowed today
            String borrowedText = this.jTFBorrowedDate.getText().trim();
            if (borrowedText.isEmpty()) {
                f.borrowed = LocalDate.now();
                this.jTFBorrowedDate.setText(f.borrowed.toString());
            } else {
                try {
                    f.borrowed = LocalDate.parse(borrowedText);
                } catch (DateTimeParseException ex) {
                    showError("Borrowed date must be yyyy-MM-dd (e.g. 2026-11-03)");
                    return null;
                }
            }

            try {
                f.due = LocalDate.parse(this.jTFDueDate.getText().trim());
            } catch (DateTimeParseException ex) {
                showError("Due date must be yyyy-MM-dd (e.g. 2026-11-16)");
                return null;
            }
            if (f.due.isBefore(f.borrowed)) {
                showError("Due date cannot be earlier than the borrowed date");
                return null;
            }
        }
        return f;
    }

    // ---------- open the Equipment Type form ----------
    private void openEquipmentTypeForm() {
        if (typeForm == null || !typeForm.isDisplayable()) {
            typeForm = new EquipmentTypeUI(typeController);
            typeController.setView(typeForm);
            typeForm.addWindowListener(
                new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosed(java.awt.event.WindowEvent e) {
                        populateComboBox();
                        refreshEquipments();
                    }
                }
            );
        }
        typeForm.setLocationRelativeTo(this);
        typeForm.setVisible(true);
        typeForm.toFront();
        typeForm.requestFocus();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableEquipments = new javax.swing.JTable();
        jTFName = new javax.swing.JTextField();
        jTFSerialNo = new javax.swing.JTextField();
        jComboBoxType = new javax.swing.JComboBox<>();
        jTFBorrowerName = new javax.swing.JTextField();
        jComboBoxBorrowerType = new javax.swing.JComboBox<>();
        jTFBorrowedDate = new javax.swing.JTextField();
        jTFDueDate = new javax.swing.JTextField();
        jBtnAdd = new javax.swing.JButton();
        jBtnUpdate = new javax.swing.JButton();
        jBtnDelete = new javax.swing.JButton();
        jBtnReturn = new javax.swing.JButton();
        jBtnClear = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuManage = new javax.swing.JMenu();
        jMenuItemType = new javax.swing.JMenuItem();
        jMenuSort = new javax.swing.JMenu();
        jMenuItemSortName = new javax.swing.JMenuItem();
        jMenuItemSortSerial = new javax.swing.JMenuItem();
        jMenuItemSortType = new javax.swing.JMenuItem();
        jMenuItemSortStatus = new javax.swing.JMenuItem();
        jMenuItemSortDue = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Equipment Borrowing System");

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Equipment Borrowing System");

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Equipment", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION));

        jTableEquipments.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(jTableEquipments);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTFName.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTFName.setBorder(javax.swing.BorderFactory.createTitledBorder("Equipment Name"));

        jTFSerialNo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTFSerialNo.setBorder(javax.swing.BorderFactory.createTitledBorder("Serial No."));

        jComboBoxType.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jComboBoxType.setBorder(javax.swing.BorderFactory.createTitledBorder("Equipment Type"));

        jTFBorrowerName.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTFBorrowerName.setBorder(javax.swing.BorderFactory.createTitledBorder("Borrower Name"));

        jComboBoxBorrowerType.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jComboBoxBorrowerType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Student", "Faculty", "Staff", "Guest" }));
        jComboBoxBorrowerType.setBorder(javax.swing.BorderFactory.createTitledBorder("Borrower Type"));

        jTFBorrowedDate.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTFBorrowedDate.setBorder(javax.swing.BorderFactory.createTitledBorder("Borrowed Date (yyyy-MM-dd)"));

        jTFDueDate.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTFDueDate.setBorder(javax.swing.BorderFactory.createTitledBorder("Due Date (yyyy-MM-dd)"));

        jBtnAdd.setFont(new java.awt.Font("sansserif", 1, 14)); // NOI18N
        jBtnAdd.setText("Add");
        jBtnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnAddActionPerformed(evt);
            }
        });

        jBtnUpdate.setFont(new java.awt.Font("sansserif", 1, 14)); // NOI18N
        jBtnUpdate.setText("Update");
        jBtnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnUpdateActionPerformed(evt);
            }
        });

        jBtnDelete.setFont(new java.awt.Font("sansserif", 1, 14)); // NOI18N
        jBtnDelete.setText("Delete");
        jBtnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnDeleteActionPerformed(evt);
            }
        });

        jBtnReturn.setFont(new java.awt.Font("sansserif", 1, 14)); // NOI18N
        jBtnReturn.setText("Return Item");
        jBtnReturn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnReturnActionPerformed(evt);
            }
        });

        jBtnClear.setFont(new java.awt.Font("sansserif", 1, 14)); // NOI18N
        jBtnClear.setText("Clear");
        jBtnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnClearActionPerformed(evt);
            }
        });

        jMenu1.setText("File");
        jMenuBar1.add(jMenu1);

        jMenuManage.setText("Manage");

        jMenuItemType.setText("Equipment Type");
        jMenuItemType.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemTypeActionPerformed(evt);
            }
        });
        jMenuManage.add(jMenuItemType);

        jMenuBar1.add(jMenuManage);

        jMenuSort.setText("Sort");

        jMenuItemSortName.setText("Name (A-Z)");
        jMenuItemSortName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemSortNameActionPerformed(evt);
            }
        });
        jMenuSort.add(jMenuItemSortName);

        jMenuItemSortSerial.setText("Serial No. (A-Z)");
        jMenuItemSortSerial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemSortSerialActionPerformed(evt);
            }
        });
        jMenuSort.add(jMenuItemSortSerial);

        jMenuItemSortType.setText("Equipment Type");
        jMenuItemSortType.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemSortTypeActionPerformed(evt);
            }
        });
        jMenuSort.add(jMenuItemSortType);

        jMenuItemSortStatus.setText("Status (Overdue first)");
        jMenuItemSortStatus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemSortStatusActionPerformed(evt);
            }
        });
        jMenuSort.add(jMenuItemSortStatus);

        jMenuItemSortDue.setText("Due Date (earliest first)");
        jMenuItemSortDue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemSortDueActionPerformed(evt);
            }
        });
        jMenuSort.add(jMenuItemSortDue);

        jMenuBar1.add(jMenuSort);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTFName, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTFSerialNo, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBoxType, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTFBorrowerName, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBoxBorrowerType, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTFBorrowedDate, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTFDueDate, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jBtnAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jBtnUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jBtnDelete, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jBtnReturn, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jBtnClear, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel1)
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jTFName, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(jTFSerialNo, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(jComboBoxType, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jTFBorrowerName, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(jComboBoxBorrowerType, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(jTFBorrowedDate, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(jTFDueDate, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jBtnAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(jBtnUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(jBtnDelete, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(jBtnReturn, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(jBtnClear, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuItemTypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemTypeActionPerformed
        openEquipmentTypeForm();
    }//GEN-LAST:event_jMenuItemTypeActionPerformed

    private void jMenuItemSortNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemSortNameActionPerformed
        applySort(EquipmentController.SORT_NAME, "Name (A-Z)");
    }//GEN-LAST:event_jMenuItemSortNameActionPerformed

    private void jMenuItemSortSerialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemSortSerialActionPerformed
        applySort(EquipmentController.SORT_SERIAL, "Serial No. (A-Z)");
    }//GEN-LAST:event_jMenuItemSortSerialActionPerformed

    private void jMenuItemSortTypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemSortTypeActionPerformed
        applySort(EquipmentController.SORT_TYPE, "Equipment Type");
    }//GEN-LAST:event_jMenuItemSortTypeActionPerformed

    private void jMenuItemSortStatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemSortStatusActionPerformed
        applySort(EquipmentController.SORT_STATUS, "Status (Overdue first)");
    }//GEN-LAST:event_jMenuItemSortStatusActionPerformed

    private void jMenuItemSortDueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemSortDueActionPerformed
        applySort(EquipmentController.SORT_DUE, "Due Date (earliest first)");
    }//GEN-LAST:event_jMenuItemSortDueActionPerformed

    private void jBtnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnAddActionPerformed
        FormData f = readForm();
        if (f == null) {
            return;
        }

        boolean res = controller.handleAddEquipment(this.jTFName.getText(), this.jTFSerialNo.getText(),
                f.typeId, f.borrower, f.borrowerType, f.borrowed, f.due);

        if (res) {
            JOptionPane.showMessageDialog(this, "New equipment added", "Equipment Borrowing", JOptionPane.INFORMATION_MESSAGE);
            setUpDefaults();
        } else {
            JOptionPane.showMessageDialog(this, "Error adding equipment (check required fields / duplicate serial no.)", "Equipment Borrowing", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jBtnAddActionPerformed

    private void jBtnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnUpdateActionPerformed
        FormData f = readForm();
        if (f == null) {
            return;
        }

        boolean res = controller.handleUpdateEquipment(this.selectedEquipmentId, this.jTFName.getText(),
                this.jTFSerialNo.getText(), f.typeId, f.borrower, f.borrowerType, f.borrowed, f.due);

        if (res) {
            JOptionPane.showMessageDialog(this, "Equipment data updated", "Equipment Borrowing", JOptionPane.INFORMATION_MESSAGE);
            setUpDefaults();
        } else {
            JOptionPane.showMessageDialog(this, "Error updating equipment (check required fields / duplicate serial no.)", "Equipment Borrowing", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jBtnUpdateActionPerformed

    private void jBtnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnDeleteActionPerformed
        int confirm = JOptionPane.showConfirmDialog(this, "Delete this equipment?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }
        boolean res = controller.handleDeleteEquipment(this.selectedEquipmentId);
        if (res) {
            JOptionPane.showMessageDialog(this, "Equipment deleted", "Equipment Borrowing", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Error deleting equipment", "Equipment Borrowing", JOptionPane.ERROR_MESSAGE);
        }
        setUpDefaults();
    }//GEN-LAST:event_jBtnDeleteActionPerformed

    private void jBtnReturnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnReturnActionPerformed
        Equipment equipment = controller.getEquipmentDetails(this.selectedEquipmentId);
        if (equipment == null || equipment.isAvailable()) {
            return;
        }
        // check if it is returned late (before the due date is cleared)
        long lateDays = Math.max(0, ChronoUnit.DAYS.between(equipment.getDueDate(), LocalDate.now()));

        boolean res = controller.handleReturnEquipment(this.selectedEquipmentId);
        if (res) {
            JOptionPane.showMessageDialog(this,
                    "Equipment returned. It is now available." + (lateDays > 0 ? "\nReturned " + lateDays + " day(s) late." : ""),
                    "Equipment Borrowing", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Error returning equipment", "Equipment Borrowing", JOptionPane.ERROR_MESSAGE);
        }
        setUpDefaults();
    }//GEN-LAST:event_jBtnReturnActionPerformed

    private void jBtnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnClearActionPerformed
        setUpDefaults();
    }//GEN-LAST:event_jBtnClearActionPerformed

    private final EquipmentTableModel tableModel;
    private final EquipmentController controller;
    private String selectedEquipmentId;
    private String currentSort = EquipmentController.SORT_NAME;
    private String currentSortLabel = "Name (A-Z)";

    private EquipmentTypeManager typeManager;
    private EquipmentTypeController typeController;
    private EquipmentTypeUI typeForm;

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBtnAdd;
    private javax.swing.JButton jBtnClear;
    private javax.swing.JButton jBtnDelete;
    private javax.swing.JButton jBtnReturn;
    private javax.swing.JButton jBtnUpdate;
    private javax.swing.JComboBox<String> jComboBoxBorrowerType;
    private javax.swing.JComboBox<EquipmentType> jComboBoxType;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItemSortDue;
    private javax.swing.JMenuItem jMenuItemSortName;
    private javax.swing.JMenuItem jMenuItemSortSerial;
    private javax.swing.JMenuItem jMenuItemSortStatus;
    private javax.swing.JMenuItem jMenuItemSortType;
    private javax.swing.JMenuItem jMenuItemType;
    private javax.swing.JMenu jMenuManage;
    private javax.swing.JMenu jMenuSort;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTFBorrowedDate;
    private javax.swing.JTextField jTFBorrowerName;
    private javax.swing.JTextField jTFDueDate;
    private javax.swing.JTextField jTFName;
    private javax.swing.JTextField jTFSerialNo;
    private javax.swing.JTable jTableEquipments;
    // End of variables declaration//GEN-END:variables
}
