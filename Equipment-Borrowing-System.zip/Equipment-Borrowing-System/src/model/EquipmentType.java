/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author
 */
import java.io.Serializable;

/**
 * Lookup entity (like Category).
 */
public class EquipmentType implements Serializable {
    private static final long serialVersionUID = 1L;

    private int id;
    private String typeName;

    public EquipmentType(int id, String typeName) {
        this.id = id;
        this.typeName = typeName;
    }

    public int getId() {
        return id;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    @Override
    public String toString() {
        return this.typeName;   // shown in the combo box
    }
}
