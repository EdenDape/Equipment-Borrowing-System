/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author
 */
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import utils.FileDBHelper;

public class EquipmentManager {
    private HashMap<String, Equipment> equipments;
    private final String FILE_PATH = "equipments.ser";

    public EquipmentManager(){
        equipments = new HashMap<>();
        FileDBHelper.createFile(FILE_PATH);
    }

    public void addEquipment(Equipment equipment){
        equipments.put(equipment.getEquipmentId(), equipment);
    }

    public Equipment findEquipment(String id){
        return equipments.get(id);
    }

    public Equipment deleteEquipment(String id){
        Equipment equipment = equipments.remove(id);
        return equipment;
    }

    /** True if another equipment (not excludeId) already uses this serial number. */
    public boolean serialExists(String serial, String excludeId){
        for (Equipment c : equipments.values()) {
            if (c.getSerialNo().equalsIgnoreCase(serial) && !c.getEquipmentId().equals(excludeId)) {
                return true;
            }
        }
        return false;
    }

    public int saveEquipments() {
        int errorCode = 0; //0:success; -1:error
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(FileDBHelper.DIRECTORY + this.FILE_PATH);
            //create object output stream
            try(ObjectOutputStream oos = new ObjectOutputStream(fos)){
                //write the object to file
                oos.writeObject(equipments);
            }
            fos.close();
        } catch (IOException e) {
            errorCode = -1;
            System.out.println("Error: " + e);
        }
        return errorCode;
    }

    @SuppressWarnings("unchecked")
    public void loadEquipments(){
        File file = new File(FileDBHelper.DIRECTORY + FILE_PATH);
        if (file.length() == 0) {
            return; //nothing saved yet
        }
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(file);
            try(ObjectInputStream ois = new ObjectInputStream(fis)){
                Object readObj = ois.readObject();
                this.equipments = (HashMap<String, Equipment>) readObj;
            }
            fis.close();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error Read: " + e);
        }
    }

    public HashMap<String, Equipment> findAll(){
        return this.equipments;
    }

}
