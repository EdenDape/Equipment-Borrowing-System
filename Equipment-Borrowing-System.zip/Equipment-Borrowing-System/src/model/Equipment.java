/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author
 */

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Random;

/**
 * Main entity (like Item).
 */
public class Equipment implements Serializable {
    private static final long serialVersionUID = 1L;

    private String equipmentId;
    private String name;
    private String serialNo;
    private int equipmentTypeId;
    private boolean available;
    private String borrowerName;   // "" when available
    private String borrowerType;   // Student / Faculty / Staff / Guest; "" when available
    private LocalDate borrowedDate; // null when available
    private LocalDate dueDate;     // null when available

    /** Choices shown in the Borrower Type combo box. */
    public static final String[] BORROWER_TYPES = {"Student", "Faculty", "Staff", "Guest"};

    // new equipment: the id is generated here (same as Item)
    public Equipment(String name, String serialNo, int equipmentTypeId,
                     boolean available, String borrowerName, String borrowerType,
                     LocalDate borrowedDate, LocalDate dueDate) {
        this.name = name;
        this.serialNo = serialNo;
        this.equipmentTypeId = equipmentTypeId;
        this.available = available;
        this.borrowerName = borrowerName;
        this.borrowerType = borrowerType;
        this.borrowedDate = borrowedDate;
        this.dueDate = dueDate;
        this.equipmentId = generateRandomId();
    }

    // equipment with a known id
    public Equipment(String equipmentId, String name, String serialNo, int equipmentTypeId,
                     boolean available, String borrowerName, String borrowerType,
                     LocalDate borrowedDate, LocalDate dueDate) {
        this.equipmentId = equipmentId;
        this.name = name;
        this.serialNo = serialNo;
        this.equipmentTypeId = equipmentTypeId;
        this.available = available;
        this.borrowerName = borrowerName;
        this.borrowerType = borrowerType;
        this.borrowedDate = borrowedDate;
        this.dueDate = dueDate;
    }

    private String generateRandomId() {
        LocalDate today = LocalDate.now();
        Random r = new Random();
        int num = r.nextInt(9999);
        long timestamp = System.currentTimeMillis() % 1000000;
        String lastseq = String.format("%04d", num);
        String id = String.format("%d-%d-%s", today.getYear(), timestamp, lastseq);

        return id;
    }

    public String getEquipmentId() { return equipmentId; }
    public String getName() { return name; }
    public String getSerialNo() { return serialNo; }
    public int getEquipmentTypeId() { return equipmentTypeId; }
    public boolean isAvailable() { return available; }
    public String getBorrowerName() { return borrowerName; }
    // null-safe: records saved before these fields existed come back as null
    public String getBorrowerType() { return borrowerType == null ? "" : borrowerType; }
    public LocalDate getBorrowedDate() { return borrowedDate; }
    public LocalDate getDueDate() { return dueDate; }

    public void setName(String name) { this.name = name; }
    public void setSerialNo(String serialNo) { this.serialNo = serialNo; }
    public void setEquipmentTypeId(int equipmentTypeId) { this.equipmentTypeId = equipmentTypeId; }
    public void setAvailable(boolean available) { this.available = available; }
    public void setBorrowerName(String borrowerName) { this.borrowerName = borrowerName; }
    public void setBorrowerType(String borrowerType) { this.borrowerType = borrowerType; }
    public void setBorrowedDate(LocalDate borrowedDate) { this.borrowedDate = borrowedDate; }
    public void setDueDate(LocalDate dueDate) { this.dueDate = dueDate; }

    /** Equipment comes back: available again, borrower, type and dates cleared. */
    public void returnEquipment() {
        this.available = true;
        this.borrowerName = "";
        this.borrowerType = "";
        this.borrowedDate = null;
        this.dueDate = null;
    }

    public boolean isOverdue() {
        return !available && dueDate != null && LocalDate.now().isAfter(dueDate);
    }

    public String getStatus() {
        if (available) return "Available";
        return isOverdue() ? "OVERDUE" : "Borrowed";
    }

    @Override
    public String toString() {
        return "Equipment{" + "equipmentId=" + equipmentId + ", name=" + name
                + ", serialNo=" + serialNo + ", status=" + getStatus() + '}';
    }
}
