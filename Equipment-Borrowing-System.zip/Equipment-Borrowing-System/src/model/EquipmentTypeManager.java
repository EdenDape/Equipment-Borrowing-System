/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author
 */
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import utils.FileDBHelper;

public class EquipmentTypeManager {
    private HashMap<Integer, EquipmentType> equipmentTypes;
    private final String FILE_PATH = "equipmenttypes.ser";

    public EquipmentTypeManager(){
        equipmentTypes = new HashMap<>();
        FileDBHelper.createFile(FILE_PATH);
    }

    public void addEquipmentType(EquipmentType equipmentType){
        equipmentTypes.put(equipmentType.getId(), equipmentType);
    }

    public EquipmentType findEquipmentType(int id){
        return equipmentTypes.get(id);
    }

    /** Next free id for a new equipmentType. */
    public int nextId(){
        int max = 0;
        for (int id : equipmentTypes.keySet()) {
            max = Math.max(max, id);
        }
        return max + 1;
    }

    public int saveEquipmentTypes(){
        int errorCode = 0; //0-success; -1-error
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(FileDBHelper.DIRECTORY + this.FILE_PATH);
            //create object output stream
            try(ObjectOutputStream oos = new ObjectOutputStream(fos)){
                //write the object to file
                oos.writeObject(equipmentTypes);
            }
            fos.close();
        } catch (IOException e) {
            errorCode = -1;
            System.out.println("Error: " + e);
        }
        return errorCode;
    }

    @SuppressWarnings("unchecked")
    public void loadEquipmentTypes(){
        File file = new File(FileDBHelper.DIRECTORY + FILE_PATH);
        if (file.length() == 0) {
            return; //nothing saved yet
        }
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(file);
            try(ObjectInputStream ois = new ObjectInputStream(fis)){
                Object readObj = ois.readObject();
                this.equipmentTypes = (HashMap<Integer, EquipmentType>) readObj;
            }
            fis.close();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error Read: " + e);
        }
    }

    public HashMap<Integer, EquipmentType> findAll(){
        return this.equipmentTypes;
    }

}
